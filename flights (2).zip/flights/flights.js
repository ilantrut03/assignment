$(document).ready(function () {
	var nbSteps = 100;
	var currentTime = 0;
	const background = new Image();
	background.src = "img/Canada-1280-1107.png";
	var canvas = document.getElementById('myCanvas');
	var ctx = canvas.getContext('2d');
	var arrFlights = new Array();
	
	$(canvas).css({
		"background-image" : `url(${background.src}')`,
		"background-size" : "100% 100%",
	});

	canvas.addEventListener("click", () => {
		var myObj = new Object();


		$.getJSON("capitals.json", function( json ){
			myObj = json;
			arrFlights = myObj.flights.map(f =>{
				p = new Plane();
				p.positionX = f.departureX;
				p.positionY = f.departureY;
            	return p;
			});

			for(var index = 0;index < 190; index++){
				arrFlights[index] = new Plane();	
				arrFlights[index].positionX = parseInt(myObj.flights[index].departureX);
				arrFlights[index].positionY = parseInt(myObj.flights[index].departureY);
				arrFlights[index].arrivalX = parseInt(myObj.flights[index].arrivalX);
				arrFlights[index].arrivalY = parseInt(myObj.flights[index].arrivalY);
				arrFlights[index].departureTime = parseInt(myObj.flights[index].departureTime);
				if(myObj.flights[index].departure != "Iqaluit" && myObj.flights[index].departure != "Whitehorse" && myObj.flights[index].departure != "Yellowknife" ){
					arrFlights[index].imageFile = myObj.flights[index].departure;	
				}
				arrFlights[index].calculateTrajectory();
			}							
		});
		
		setInterval(function(){
			ctx.clearRect(0,0,canvas.width,canvas.height);
		
			for (var index = 0; index < arrFlights.length; index++) {
				if(currentTime >= arrFlights[index].departureTime) {
					arrFlights[index].drawItSelf();
					arrFlights[index].updatePosition();
	
					if(arrFlights[index].currentStep > nbSteps){
					arrFlights.splice(index,1);
					}
				}
			}
		currentTime++;
		}, 75);	
	});

	class Plane {
		constructor(){
			this.imageFile = "plane";
			this.positionX = 0;
			this.positionY = 0;
			this.departureTime = 0;
			this.arrivalX = 0; 
			this.arrivalY = 0;
			this.currentStep = 0; 
			this.incrementStepsX = 0;
			this.incrementStepsY = 0;
			this.drawItSelf = function() {
				var img = new Image();
				var dotIndex = this.imageFile.lastIndexOf('.');
				var ext = this.imageFile.substring(dotIndex);
				if(this.imageFile.includes("jpg")){
					img.src = "img/" + this.imageFile.toLowerCase() + ".jpg";

				}else{
					img.src = "img/" + this.imageFile.toLowerCase() + ".png";

				}
  				ctx.drawImage(img, this.positionX, this.positionY, 30 ,30);
			};
			this.calculateTrajectory = function() {
				this.incrementStepsX = (this.arrivalX - this.positionX) / nbSteps;
				this.incrementStepsY = (this.arrivalY - this.positionY) / nbSteps;
			};
			this.updatePosition = function() {
				this.positionX = this.positionX + this.incrementStepsX;
				this.positionY = this.positionY + this.incrementStepsY;
				this.currentStep = this.currentStep + 1;
			};				
		}
	}	
});

